﻿<?php

defined('CP') || exit('CarPrices: access denied.');

class Model_change_password extends Model
{

}