<?php

defined('CP') || exit('CarPrices: access denied.');

class Model
{
    public function get_data() {}
}